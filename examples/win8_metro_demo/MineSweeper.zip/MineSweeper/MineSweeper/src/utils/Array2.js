/**
 * 
 */
 
var Array2 = function(w, h)
{
	if (w < 1 || h < 1) throw Error("illegal size");
	this.width = w;
	this.height = h;
	this.arr = [];
}

Array2.prototype.get = function(x, y)
{
	if(x < 0 || x >= this.width || y < 0 || y >= this.height) return null;
	return this.arr[y * this.width + x];
}

Array2.prototype.set = function(x, y, obj)
{
	if(x < 0 || x >= this.width || y < 0 || y >= this.height) return;
	this.arr[y * this.width + x] = obj;
}
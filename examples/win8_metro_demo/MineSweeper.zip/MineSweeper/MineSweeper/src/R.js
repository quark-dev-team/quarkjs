/**
 * Resource manager
 */
 
R = {};

R.images = null;

R.sources = [
{src:'images/stage1.jpg', size:137},
{src:'images/stage1_border.png', size:27},
{src:'images/tiles.png', size:8},
{src:'images/sweeper.png', size:84},
{src:'images/layout.png', size:93}
];

R.init = function(images)
{
	this.images = images;
	
	this.bg = images[0].image;
	this.border = images[1].image;	
	this.tiles = images[2].image;
	this.tileUp = new Bitmap(this.tiles, [132, 0, 44, 29]);
	this.tileOver = new Bitmap(this.tiles, [88, 0, 44, 27]);
	this.tileDown = new Bitmap(this.tiles, [44, 0, 44, 25]);
	this.flag = new Bitmap(this.tiles, [425, 0, 28, 24]);
	this.quest = new Bitmap(this.tiles, [176, 0, 19, 27]);
	this.minea = new Bitmap(this.tiles, [385, 0, 18, 20, 9, 10]);
	this.mineb = new Bitmap(this.tiles, [403, 0, 22, 23, 11, 11]);	
	this.num1 = new Bitmap(this.tiles, [368, 0, 17, 25]);
	this.num2 = new Bitmap(this.tiles, [343, 0, 25, 28]);
	this.num3 = new Bitmap(this.tiles, [318, 0, 25, 27]);
	this.num4 = new Bitmap(this.tiles, [295, 0, 23, 29]);
	this.num5 = new Bitmap(this.tiles, [270, 0, 25, 29]);
	this.num6 = new Bitmap(this.tiles, [246, 0, 24, 27]);
	this.num7 = new Bitmap(this.tiles, [220, 0, 26, 28]);
	this.num8 = new Bitmap(this.tiles, [195, 0, 25, 27]);
	
	this.sweeper = images[3].image;
	this.layout = images[4].image;
	this.win = new Bitmap(this.layout, [0, 140, 248, 83]);
	this.lose = new Bitmap(this.layout, [0, 0, 288, 83]);
	this.minebar = new Bitmap(this.layout, [288, 0, 135, 57]);
	this.timebar = new Bitmap(this.layout, [0, 83, 293, 57]);
	
	this.sweeperFrames = 
	[
		new Frame(new Bitmap(this.sweeper, [98, 66, 32, 53, 0, -13]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [211, 0, 31, 57, 0, -9]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [180, 0, 31, 60, 0, -6]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [149, 0, 31, 63, 0, -3]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [118, 0, 31, 65, 0, -1]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [87, 0, 31, 66, 0, 0]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [56, 0, 31, 61, 0, -5]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [28, 0, 28, 62, 0, -4]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 0, 28, 62, 0, -4]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [67, 66, 31, 63, 0, -3]), null, null, 2, 1),
		new Frame(new Bitmap(this.sweeper, [36, 66, 31, 65, 0, -1]), "ok", null, 20),	
		new Frame(new Bitmap(this.sweeper, [0, 66, 36, 61, 4, -4]), "bomb", null, 2),	
		new Frame(new Bitmap(this.sweeper, [453, 0, 37, 61, 4, -4]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [417, 0, 36, 61, 4, -4]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [381, 0, 36, 61, 4, -4]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [346, 0, 35, 62, 3, -3]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [311, 0, 35, 62, 3, -3]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [276, 0, 35, 62, 3, -3]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [242, 0, 34, 61, 3, -4]), null, "bomb", 2)
	];
	
	this.flameFrames = 
	[
		new Frame(new Bitmap(this.sweeper, [285, 813, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 647, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 481, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 315, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 149, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [415, 66, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [320, 66, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [225, 66, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [130, 66, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 813, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 813, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 813, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 730, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 730, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 730, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 730, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 730, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 647, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 647, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 647, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 647, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 564, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 564, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 564, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 564, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 564, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 481, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 481, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 481, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 481, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 398, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 398, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 398, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 398, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 398, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 315, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 315, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 315, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 315, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 232, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 232, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 232, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 232, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [0, 232, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [380, 149, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [285, 149, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [190, 149, 95, 83]), null, null, 2),
		new Frame(new Bitmap(this.sweeper, [95, 149, 95, 83]), null, null, 2, 1)
	];
}
/**
 * 
 */
 
var Tile = function(px, py)
{
	Sprite.call(this);
	this.px = px;
	this.py = py;
	this.actived = true;
	this.revealed = false;
	
	this.init();
}
casual.inherit(Tile, Sprite);

Tile.prototype.init = function()
{	
	var upState = casual.copy(R.tileUp);
	var overState = casual.copy(R.tileOver, null, {y:2});
	var downState = casual.copy(R.tileDown, null, {y:4});
	
	var btn = new Button(upState, overState, downState);
	this.addChild(btn);
	this.skin = btn;
	
	this.width = upState.width;
	this.height = upState.height;
	this.mouseChildren = false;
}

Tile.prototype.addMark = function(id, state)
{	
	if(this.mark) 
	{
		if(id && this.mark.id == id) return;
		this.removeChild(this.mark);
		this.mark = null;
	}
	if(!id) return;
	
	var m;
	switch(id)
	{
		case "mine":
		var a = casual.copy(R.minea);
		var b = casual.copy(R.mineb);
		m = new MovieClip();
		m.addFrame(new Frame(a, null, null, 20));
		m.addFrame(new Frame(b, null, null, 20));
		m.x = 22;
		m.y = 8;
		break;
		
		case "quest":
		m = casual.copy(R[id]);
		m.x = this.width - m.width >> 1;
		m.y = -8;
		break;
		
		default:
		m = casual.copy(R[id]);
		m.x = this.width - m.width >> 1;
		m.y = -6;
		break;
	}
	m.id = id;
	this.addChild(m);
	this.mark = m;
	
	this.setState(state || Button.state.DOWN);
	this.actived = false;
}

Tile.prototype.setMine = function()
{
	this.isMine = true;
}

Tile.prototype.setState = function(state)
{
	this.skin.setState(state);	
}

Tile.prototype.toString = function()
{
	return "Tile_" + this.px + "_" + this.py;
}
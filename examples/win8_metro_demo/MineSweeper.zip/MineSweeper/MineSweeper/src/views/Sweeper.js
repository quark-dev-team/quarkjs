/**
 * 
 */
 
var Sweeper = function()
{
	MovieClip.call(this);
	this.init();
	
	this.onshow = null;
	this.onok = null;
	this.onbomb = null;
	this.flameShown = false;
}
casual.inherit(Sweeper, MovieClip);

Sweeper.prototype.init = function()
{	
	this.addFrame(R.sweeperFrames);
	
	var flame = new MovieClip();
	flame.addFrame(R.flameFrames);	
	flame.x = -35;
	flame.y = -10;
	this.flame = flame;	
}

Sweeper.prototype.render = function(context)
{
	Sweeper.superClass.render.call(this, context);
	
	if(this.currentFrame == 10 && this.onshow != null) 
	{
		this.onshow(this);
	}else if(this.currentFrame == 11 && this.onok != null && this._pauseFrames >= 20) 
	{
		this.onok(this);
	}else if(this.currentFrame == 12 && !this.flameShown) 
	{
		this.addChild(this.flame);
		this.flame.gotoAndPlay(1);
		this.flameShown = true;
		if(this.onbomb != null) this.onbomb(this);
	}
	
	if(this.contains(this.flame) && this.flame.currentFrame == this.flame.getTotalFrames())
	{
		this.removeChild(this.flame);
	}
}
/**
 * 
 */
 
var Map = function(width, height, tileWidth, tileHeight, mineCount)
{
	Sprite.call(this);
	
	this.width = width;
	this.height = height;
	this.tileWidth = tileWidth;
	this.tileHeight = tileHeight;
	this.tiles = new Array2(this.width, this.height);
	this.size = width * height;
	
	this.mineCount = mineCount;
	this.mines = [];
	this.revealedMines = [];
	
	this.init();
}
casual.inherit(Map, Sprite);

Map.prototype.init = function()
{	
	//create random mines
	var mineArr = [], temp = [];
	for(var i = 0; i < this.size; i++)
	{
		temp[i] = i;
	}	
	for(var i = 0; i < this.mineCount; i++)
	{
		var rnd = Math.floor(Math.random()*temp.length);
		mineArr.push(temp[rnd]);
		temp.splice(rnd, 1);
	}
	
	//build tile map
	for(var i = 0; i < this.height; i++)
	{
		for(var j = 0; j < this.width; j++)
		{
			var tile = new Tile(j, i);
			var pos = this.mapToCoord(j, i);
			tile.x = pos.x;
			tile.y = pos.y;
			if(mineArr.indexOf(i*this.width+j) != -1)
			{
				tile.setMine();
				this.mines.push(tile);
			}
			tile.neighborMines = this.getTileNeighborMines(tile, mineArr);
			this.addChild(tile);
			this.tiles.set(j, i, tile);
		}
	}
}

Map.prototype.getTileNeighborMines = function(tile, mines)
{
	var result = [];
	for(var i = 0; i < neighbors.length; i++)
	{
		var n = neighbors[i], nx = tile.px + n[0], ny = tile.py + n[1];
		if(nx < 0 || nx >= this.width || ny < 0 || ny >= this.height) continue;
		if(mines.indexOf(ny*this.width+nx) != -1) result.push(n);
	}
	return result;
}

Map.prototype.revealAllMines = function(tile)
{
	for(var i = 0; i < this.mines.length; i++)
	{
		var t = this.mines[i];
		if(t == tile) continue;
		t.revealed = true;
		t.addMark("mine", Button.state.OVER);
	}
}

Map.prototype.exploreEmptyTiles = function(tile, explored)
{
	if(!explored) explored = [tile];
	for(var i = 0; i < neighbors.length; i++)
	{
		var n = neighbors[i], nx = tile.px + n[0], ny = tile.py + n[1];
		if(nx < 0 || nx >= this.width || ny < 0 || ny >= this.height) continue;
		var t = this.getTileAt(nx, ny);
		if(t && explored.indexOf(t) == -1 && !t.isMine)
		{			
			explored.push(t);
			if(t.neighborMines.length > 0)
			{
				t.revealed = true;
				t.addMark("num" + t.neighborMines.length, Button.state.DOWN);
			}else
			{
				t.setState(Button.state.DOWN);
				t.actived = false;
				t.revealed = true;
				this.exploreEmptyTiles(t, explored);
			}
		}else
		{
			explored.push(t);
		}
	}
}

Map.prototype.getTileAt = function(px, py)
{	
	return this.tiles.get(px, py);
}

Map.prototype.getTileAtCoord = function(cx, cy)
{
	var p = this.coordToMap(cx, cy);
	return this.getTileAt(p.x, p.y);
}

Map.prototype.coordToMap = function(cx, cy)
{
	var x = cx - Math.ceil(this.height * this.tileWidth * 0.5); 
	var ny = (2 * cy - x);
    var nx = (x + ny * 0.5) * 2;
    var px = Math.ceil(nx / this.tileWidth) - 1;
    var py = Math.ceil(ny / this.tileWidth) - 1;
	return {x:px, y:py};
}

Map.prototype.mapToCoord = function(px, py)
{
	var x = (px - py) * this.tileWidth * 0.5 + (this.height - 1) * this.tileWidth * 0.5;
	var y = (px + py) * this.tileHeight * 0.5;
	return {x:x, y:y};
}

var neighbors = [[-1, 0], [1, 0], [-1, -1], [0, -1], [1, -1], [-1, 1], [0, 1], [1, 1]];
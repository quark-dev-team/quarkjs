/**
 * 2D Mine Sweeper
 */
 
/*/
window.onload = function()
{
	game.startup({left:0, top:0, container:document.getElementById("game")});
}
//*/
 
game = 
{
	frames: 0
};

game.createDOM = function(type, props)
{
	var dom = document.createElement(type);
	for(var p in props) 
	{
		var val = props[p];
		if(p == "style")
		{
			for(var s in val) dom.style[s] = val[s];
		}else
		{
			dom[p] = val;
		}
	}
	return dom;
}

game.createCanvas = function(params)
{
	if(!params) params = {};
	params.style = 
	{
		position: "absolute",
		left: (this.left + (params ? (params.left || 0) : 0)) + "px",
		top: (this.top + (params ? (params.top || 0) : 0)) + "px"		
	};
	return this.createDOM("canvas", params);
}

game.startup = function(params)
{
	//游戏参数设定
	this.width = params.width || 640;
	this.height = params.height || 480;
	this.left = params.left || 0;
	this.top = params.top || 0;	
	this.container = params.container || document.body;
	
	//加载进度信息
	var div = this.createDOM("div", 
	{style:{
		position: "absolute",
		width: this.width + "px",
		left: this.left + "px",
		top: ((this.top + this.height * 0.35) >> 0) + "px",
		textAlign: "center",
		color: "#333",
		font: "18px verdana",
		textShadow: "0 2px 2px #ccc"
	}});
	this.container.appendChild(div);
	this.loadContainer = div;
	
	//加载图片素材
	var loader = new ImageLoader();
	loader.addEventListener("loaded", casual.delegate(this.onLoad, this));
	loader.addEventListener("complete", casual.delegate(this.onComplete, this));	
	loader.load(R.sources);
	
	this.showProgress(0, loader.getTotalSize(), loader.getCurrentItem().src);
}

game.onLoad = function(e)
{
	//trace("onLoad:", e.image.src, e.target.getLoadedSize(), e.target.getTotalSize());
	this.showProgress(e.target.getLoadedSize(), e.target.getTotalSize(), e.image.src);
}

game.showProgress = function(loaded, total, src)
{
	this.loadContainer.innerHTML = "Loading resources, please wait...<br>";
	this.loadContainer.innerHTML += "(" + Math.round(loaded/total*100) + "%)";
	this.loadContainer.innerHTML += " " + src.substring(src.lastIndexOf("/") + 1);
}

game.onComplete = function(e)
{
	//trace("onComplete:", e.images.length);
	e.target.removeEventListener("loaded", this.onLoad);
	e.target.removeEventListener("complete", this.onComplete);
	this.container.removeChild(this.loadContainer);
	this.loadContainer = null;
	
	//图片加载完成，初始化游戏
	R.init(e.images);
	this.initGame();
}

game.initGame = function()
{
	//背景画布
	this.bgCanvas = this.createCanvas({id:"bg", left:0, top:0, width:this.width, height:this.height});
	this.bgContext = this.bgCanvas.getContext("2d");	
	this.setBackground(R.bg);
	this.container.appendChild(this.bgCanvas);
	
	//游戏主画布
	this.mainCanvas = this.createCanvas({id:"main", left:70, top:60, width:500, height:305});
	this.mainContext = this.mainCanvas.getContext("2d");
	this.container.appendChild(this.mainCanvas);		
	var stage  = new Stage(this.mainContext);
	stage.usePixelTrace = false;
	stage.setFrameRate(60);
	this.stage = stage;	
	this.buildMap();
	
	//游戏信息画布
	this.infoCanvas = this.createCanvas({id:"info", left:0, top:0, width:this.width, height:80});
	this.container.appendChild(this.infoCanvas);
	this.infoContext = this.infoCanvas.getContext("2d");
	this.infoStage = new Stage(this.infoContext);
	this.infoStage.setFrameRate(0);
	
	/*/控制按钮画布(暂未实现)
	this.controlCanvas = this.createCanvas({id:"control", left:0, top:this.height-60, width:this.width, height:60});
	this.container.appendChild(this.controlCanvas);
	this.controlContext = this.controlCanvas.getContext("2d");
	this.controlStage = new Stage(this.controlContext);
	this.controlStage.setFrameRate(0);
	//*/
	
	stage.addEventListener("enterframe", casual.delegate(this.enterFrameHandler, this));
	stage.addEventListener("mousemove", casual.delegate(this.mouseMoveHandler, this));
	stage.addEventListener("mousedown", casual.delegate(this.mouseDownHandler, this));
	
	//FPS
	setInterval(casual.delegate(this.showFPS, this), 1000);
}

game.buildMap = function()
{
	//绘制地图
	var map = new Map(10, 15, 40, 20, 14);
	map.y = 50;
	this.stage.addChild(map);
	this.map = map;
	
	//绘制地图边缘
	var border = new Bitmap(R.border);
	border.x = 2;
	border.y = 155;
	this.stage.addChild(border);
}

game.mouseMoveHandler = function(e)
{	
	if(!this.map.mouseEnabled) return;
	
	//获取当前鼠标位置的格子，重复则忽略
	var tile = this.map.getTileAtCoord(e.mouseX - this.map.x, e.mouseY - this.map.y);
	if(tile == this.lastTile) return;
	
	//释放上次的鼠标格子，恢复未选中状态
	if(this.lastTile && this.lastTile.actived)
	{
		this.lastTile.setState(Button.state.UP);
		this.lastTile = null;
	}
	
	//设置可选择格子为选中状态
	if(tile != null && tile.actived && !tile.revealed)
	{		
		if(tile.mark && (tile.mark.id == "flag" || tile.mark.id == "quest"))
		{
			return;
		}
		this.lastTile = tile;
		tile.setState(Button.state.OVER);
	}
}

game.mouseDownHandler = function(e)
{
	if(this.over)
	{
		//重新开始
		this.over = false;
		this.lastTile = null;
		this.map = null;
		this.sweeper = null;
		this.stage.removeAllChildren();
		this.buildMap();
		return;
	}
	
	if(!this.map.mouseEnabled) return;
	
	var tile = this.map.getTileAtCoord(e.mouseX - this.map.x, e.mouseY - this.map.y);
	if(tile == null || tile.revealed) return;
	
	//左键
	if(e.button == 0)
	{
		if(tile.mark && (tile.mark.id == "flag" || tile.mark.id == "quest"))
		{
			return;
		}
		
		var me = this, pos = this.map.mapToCoord(tile.px, tile.py);
		if(!this.sweeper)
		{
			this.sweeper = new Sweeper();
			this.sweeper.onshow = function(mc)
			{
				if(mc.linkTile.isMine)
				{			
					mc.gotoAndPlay("bomb");
				}else if(mc.linkTile.neighborMines.length > 0)
				{
					mc.gotoAndPlay("ok");
				}else
				{
					mc.parent.removeChild(mc);
					mc.linkTile.setState(Button.state.DOWN);
					mc.linkTile.actived = false;
					mc.linkTile.revealed = true;
					me.map.exploreEmptyTiles(mc.linkTile);
					mc.linkTile = null;
				}
			}
			this.sweeper.onok = function(mc)
			{
				mc.parent.removeChild(mc);
				mc.linkTile.revealed = true;
				mc.linkTile.addMark("num" + mc.linkTile.neighborMines.length, Button.state.DOWN);
				mc.linkTile = null;
			}
			this.sweeper.onbomb = function(mc)
			{
				me.gameOver(mc.linkTile);
				mc.linkTile = null;
			}
		}
		this.sweeper.x = this.map.x + pos.x + 7;
		this.sweeper.y = this.map.y + pos.y - 46;
		this.sweeper.gotoAndPlay(1);
		var linkTile = this.sweeper.linkTile;
		if(linkTile != null && !linkTile.revealed)
		{
			//确保在快速点击中sweeper没播放完仍能正确执行相关操作
			if(linkTile.neighborMines.length > 0)
			{
				linkTile.revealed = true;
				linkTile.addMark("num" + linkTile.neighborMines.length, Button.state.DOWN);				
			}else
			{
				linkTile.setState(Button.state.DOWN);
				linkTile.actived = false;
				linkTile.revealed = true;
				this.map.exploreEmptyTiles(linkTile);
			}
		}
		this.sweeper.linkTile = tile;
		this.stage.addChild(this.sweeper);
		
	}else if(e.button == 2) //右键
	{
		if(tile.mark)
		{
			if(tile.mark.id == "flag") 
			{
				tile.addMark("quest", Button.state.UP);
				this.updateMine(tile, false);
			}else if(tile.mark.id == "quest") 
			{
				tile.addMark(false, Button.state.UP);
			}
		}else
		{
			tile.addMark("flag", Button.state.UP);
			this.updateMine(tile, true);
		}
	}
}

game.updateMine = function(tile, asMine)
{
	var index = this.map.revealedMines.indexOf(tile);
	if(asMine && index == -1)
	{
		this.map.revealedMines.push(tile);
	}else if(!asMine && index != -1)
	{
		this.map.revealedMines.splice(index, 1);
	}
	var left = this.map.mines.length - this.map.revealedMines.length;
	trace("updateMine:", this.map.revealedMines.length, left);
	if(left == 0) this.gameOver();
}

game.gameOver = function(tile)
{
	if(tile) this.map.revealAllMines(tile);	
	this.map.mouseEnabled = false;
	if(this.lastTile && this.lastTile.actived)
	{
		this.lastTile.setState(Button.state.UP);
		this.lastTile = null;
	}
	
	//显示胜利或失败画面
	var left = this.map.mines.length - this.map.revealedMines.length;
	var win = left == 0, bmp = win ? R.win : R.lose;
	bmp.x = this.mainCanvas.width - bmp.width >> 1;
	bmp.y = this.mainCanvas.height - bmp.height >> 1;
	this.stage.addChild(bmp);
	
	this.over = true;
	
	//提示文字
	var title = new Text();
	title.font = "bold 16px Verdana";
	title.color = "#000";
	title.text = "Click anywhere to play again";
	title.x = bmp.x + 20;
	title.y = bmp.y + 105;
	
	var titleShadow = casual.copy(title);
	titleShadow.color = "#fff";
	titleShadow.x = title.x + 1;
	titleShadow.y = title.y + 1;
	
	this.stage.addChild(titleShadow);
	this.stage.addChild(title);
}

game.reset = function()
{
	this.map.mines.length = 0;
	this.map.revealedMines.length = 0;
	this.map.init();
	
	this.lastTile = null;
	if(this.sweeper) this.sweeper.linkTile = null;
}

game.setBackground = function(image)
{
	this.bgContext.clearRect(0, 0, this.width, this.height);
	this.bgContext.drawImage(image, 0, 0);
}

game.enterFrameHandler = function(e)
{
	this.frames++;
	this.infoStage.render();
	//this.controlStage.render();
}

game.showFPS = function()
{
	document.getElementById("fps").innerHTML = "FPS: " + this.frames;
	this.frames = 0;
}
﻿// 有关“空白”模板的简介，请参阅以下文档:
// http://go.microsoft.com/fwlink/?LinkId=232509
(function () {
    "use strict";

    var app = WinJS.Application;
    var activation = Windows.ApplicationModel.Activation;
    WinJS.strictProcessing();

    app.onactivated = function (args) {
        if (args.detail.kind === activation.ActivationKind.launch) {
            if (args.detail.previousExecutionState !== activation.ApplicationExecutionState.terminated) {
                // TODO: 此应用程序最近已启动。在此处初始化
                //您的应用程序。
                initSquirrel();
            } else {
                // TODO: 此应用程序已从挂起状态重新激活。
                // 在此处恢复应用程序状态。
            }
            args.setPromise(WinJS.UI.processAll());
        }
    };

    app.oncheckpoint = function (args) {
        // TODO: 即将挂起此应用程序。在此处保存
        //需要在挂起中保留的任何状态。您可以使用
        // WinJS.Application.sessionState 对象，该对象将在
        //挂起中自动保存和恢复。如果您需要在
        //挂起应用程序之前完成异步操作，请调用
        // args.setPromise()。
    };

    app.start();

    function initSquirrel() {
        var container, params, timer, stage, context, em, squirrel;

        //初始化游戏场景容器，设定背景渐变样式
        container = Q.getDOM("container");
        container.style.background = "-ms-linear-gradient(top, #00889d, #94d7e1, #58B000)";
        container.style.background = "-moz-linear-gradient(top, #00889d, #94d7e1, #58B000)";
        container.style.background = "-webkit-gradient(linear, 0 0, 0 bottom, from(#00889d), to(#58B000), color-stop(0.5,#94d7e1))";
        container.style.background = "-o-linear-gradient(top, #00889d, #94d7e1, #58B000)";

        //初始化渲染上下文，这里根据URL参数可选择是采用CanvasContext还是DOMContext
        params = Q.getUrlParams();
        if (params.canvas) {
            var canvas = Quark.createDOM("canvas", { width: 480, height: 320, style: { position: "absolute", backgroundColor: "#eee" } });
            container.appendChild(canvas);
            context = new Quark.CanvasContext({ canvas: canvas });
        } else {
            context = new Q.DOMContext({ canvas: container });
        }

        //初始化舞台
        stage = new Q.Stage({
            context: context, width: 480, height: 320
        });

        //初始化timer并启动
        timer = new Q.Timer(1000 / 60);
        timer.addListener(stage);
        timer.start();

        //注册舞台事件，使舞台上的元素能接收交互事件
        em = new Q.EventManager();
        var events = Q.supportTouch ? ["touchend"] : ["mouseup"];
        em.registerStage(stage, events, true, true);

        //创建一只松鼠，并添加到舞台
        squirrel = new Squirrel({ id: "squirrel", x: 200, y: 160, autoSize: true });
        stage.addChild(squirrel);

        //为松鼠添加touchend或mouseup事件侦听，控制其跳跃。
        squirrel.addEventListener(events[0], squirrel.jump);

        //提示信息
        var tip = Q.createDOM("span", {
            id: "tip", style:
            {
                position: "absolute",
                left: "210px",
                top: "265px",
                font: "bold 16px Arial",
                color: "#fff"
            }
        });
        tip.innerHTML = "Click me!";
        container.appendChild(tip);
    }
})();

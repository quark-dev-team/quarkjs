
(function(){
	
var Accelerometer = Quark.Accelerometer =
{
	data: {},
    _handler: Quark.delegate(this.onMotion, this)
};

Accelerometer.start = function()
{
	window.addEventListener('devicemotion', this._handler, false);
};

Accelerometer.stop = function()
{
	window.removeEventListener('devicemotion', this._handler);
};

Accelerometer.onMotion = function(e)
{
    var data = this.data;
    data.gamma = e.gamma;
    data.beta = e.beta;
    data.alpha = e.alpha;

	if(e.accelerationIncludingGravity)
	{
		data.ax = e.accelerationIncludingGravity.x;
		data.ay = e.accelerationIncludingGravity.y;
		data.az = e.accelerationIncludingGravity.z;
	}
	
	//trace("Accelerometer:", data.ax, data.ay, data.az);
};

})();